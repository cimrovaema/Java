import java.util.ArrayList;
import java.io.Serializable;
import java.util.Scanner;

/**
 * Trieda RezervovaciSystem predstavuje jednoduchy system pozicovne.
 * Uklada zoznam vozidiel, zakaznikov, historiu prenajmov a peniaze zarobene
 * z prenajmu. Umoznuje pridavat vozidla, rezervovat ich, odoberat zakaznikov
 * a vypisovat informacie.
 *
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class RezervovaciSystem implements Serializable
{

  ArrayList<Vozidlo> arr_vozidlo = new ArrayList<>(); 
  ArrayList<Zakaznik> arr_zakaznik  = new ArrayList<>();
  ArrayList<Zakaznik> arr_historiaPrenajmu = new ArrayList<>();
  
  private float peniaze = 0; 
  private String nazovRezervovaciehoSystemu = "Autobazarik";
  
  public String getNazovRezSystemu() {
      return nazovRezervovaciehoSystemu;
  }
  public float getPeniaze(){
    return peniaze;  
  }
   public void setPeniaze(float peniaze){
       this.peniaze=this.peniaze + peniaze;
   }
   
  public void pridajAuto(Auto auto){
    arr_vozidlo.add(auto);
    
  }
   public void pridajMotorka(Motorka motorka){
    arr_vozidlo.add(motorka);
    
  }
  public void pridajKamion(Kamion kamion){
   arr_vozidlo.add(kamion);
    
  }
  public void pridajAutobus(Autobus autobus){
    arr_vozidlo.add(autobus);
    
  }
  
  public void filterCarsByBrandAndColor(String znacka, String farba) {
      boolean nasielSaZaznam = false;
      for(Vozidlo auto: arr_vozidlo) {
         if  (auto instanceof Auto){
            Auto a = (Auto) auto; //pretypovanie na triedu Auto
             if (znacka.equals(a.getZnacka()) && farba.equals(a.getFarba()) && a.getJeRezervovane() == false) {
                 System.out.println("id " + a.getId());
              System.out.println("znacka " + a.getZnacka()); 
              System.out.println("model " + a.getModel());
              System.out.println("farba " + a.getFarba());
              System.out.println("rok vyroby " + a.getRokVyroby());
              System.out.println("cena za hodinu " + a.getCenaZaHodinu());
              System.out.println("palivo " + a.getPalivo());
              System.out.println("mnozstvo paliva " + a.getMnozstvoPaliva());
              System.out.println("pocet kolies " + a.getPocetKoliest());
              System.out.println("pocet dveri " + a.getPocetDveri());
              System.out.println("rezervacia " + a.getJeRezervovane());
              System.out.println("---------------------------------------");
              nasielSaZaznam = false;
             }
            
        } 
      }
      if(nasielSaZaznam == false) {
          System.out.println("Nenasiel sa pozadovany zaznam");
      }
  }
  
    /**
     * Prida zakaznika do zoznamu rezervacii a vyriesi platbu.
     * Podla vybraneho casu
     */
  public void pridajZakaznika(Zakaznik zakaznik, float vybranyCas){
    arr_zakaznik.add(zakaznik);
    if (vybranyCas == 1){
        for (Vozidlo vozidlo: arr_vozidlo){
          String nazovAuta = vozidlo.getZnacka() + vozidlo.getModel();
          if (nazovAuta.equals(zakaznik.getMenoAuta())){
            Scanner scCas = new Scanner(System.in);
            System.out.println("zadaj pocet dni"); 
            String cas = scCas.nextLine();
            System.out.println("zaplat " + vozidlo.vypocitajCenuPrenajmuDni(Float.parseFloat(cas)));  
            String peniazky = scCas.nextLine();
            if (Float.parseFloat(peniazky) == vozidlo.vypocitajCenuPrenajmuDni(Float.parseFloat(cas))){
                setPeniaze(Float.parseFloat(peniazky));
                System.out.println("zaplatil si"); 
            } else {
                System.out.println("nezaplatil si"); 
            }
            }
        }   
    }else if (vybranyCas == 2){
        for (Vozidlo vozidlo: arr_vozidlo){
          String nazovAuta = vozidlo.getZnacka() + vozidlo.getModel();
          if (nazovAuta.equals(zakaznik.getMenoAuta())){
            Scanner scCas = new Scanner(System.in);
            System.out.println("zadaj pocet hodin"); 
            String cas = scCas.nextLine();
            System.out.println("zaplat " + vozidlo.vypocitajCenuPrenajmuHod(Float.parseFloat(cas)));  
            String peniazky = scCas.nextLine();
            if (Float.parseFloat(peniazky) == vozidlo.vypocitajCenuPrenajmuHod(Float.parseFloat(cas))){
                setPeniaze(Float.parseFloat(peniazky));
                System.out.println("zaplatil si"); 
            } else {
                System.out.println("nezaplatil si"); 
            }
            }
        }  
    }
}
  
  /**
     * Prida zakaznika do histórie prenajmov.
     */
  public void pridajHistoria(Zakaznik zakaznik){
      arr_historiaPrenajmu.add(zakaznik);
  }

  public void vypisHistoria(){
      for (Zakaznik historia: arr_historiaPrenajmu){
       System.out.println("meno: " + historia.getMeno() );  
       System.out.println("email: " + historia.getEmail() ); 
       System.out.println("telefone cislo: " + historia.getTelefoneCislo() ); 
       System.out.println("meno rezervovaneho auta: " + historia.getMenoAuta() ); 
      }
  }
  
/** Vypise len auta z evidencie vozidiel. */
  public void vypisAuto(){
      for (Vozidlo auto: arr_vozidlo){
          if  (auto instanceof Auto){
          Auto a = (Auto) auto;   
          System.out.println("id " + a.getId());
          System.out.println("znacka " + a.getZnacka()); 
          System.out.println("model " + a.getModel());
          System.out.println("rok vyroby " + a.getRokVyroby());
          System.out.println("cena za hodinu " + a.getCenaZaHodinu());
          System.out.println("palivo " + a.getPalivo());
          System.out.println("mnozstvo paliva " + a.getMnozstvoPaliva());
          System.out.println("pocet kolies " + a.getPocetKoliest());
          System.out.println("pocet dveri " + a.getPocetDveri());
          System.out.println("rezervacia " + a.getJeRezervovane());
          System.out.println("---------------------------------------");
        }
      }
  }
   public void vypisAutobus(){
      for (Vozidlo autobus: arr_vozidlo){
          if  (autobus instanceof Autobus){
          Autobus a = (Autobus) autobus; 
          System.out.println("id " + a.getId());
          System.out.println("znacka " + a.getZnacka()); 
          System.out.println("model " + a.getModel());
          System.out.println("rok vyroby " + a.getRokVyroby());
          System.out.println("cena za hodinu " + a.getCenaZaHodinu());
          System.out.println("palivo " + a.getPalivo());
          System.out.println("mnozstvo paliva " + a.getMnozstvoPaliva());
          System.out.println("pocet kolies " + a.getPocetKoliest());
          System.out.println("pocet dveri " + a.getPocetDveri());
          System.out.println("rezervacia " + a.getJeRezervovane());
          System.out.println("---------------------------------------");
        }
      }
  }
  
  
   public void vypisMotorka(){
      for (Vozidlo motorka: arr_vozidlo){
          if  (motorka instanceof Motorka){
          //vytvorenie premennej a nasledne pretypovanie z triedy Vozidlo na Auto
          Motorka a = (Motorka) motorka; 
          System.out.println("id " + a.getId());
          System.out.println("znacka " + a.getZnacka()); 
          System.out.println("model " + a.getModel());
          System.out.println("rok vyroby " + a.getRokVyroby());
          System.out.println("cena za hodinu " + a.getCenaZaHodinu());
          System.out.println("palivo " + a.getPalivo());
          System.out.println("mnozstvo paliva " + a.getMnozstvoPaliva());
          System.out.println("pocet kolies " + a.getPocetKoliest());
          System.out.println("rezervacia " + a.getJeRezervovane());
          System.out.println("---------------------------------------");
        }
      }
  }
   public void vypisKamion(){
      for (Vozidlo kamion: arr_vozidlo){
          if  (kamion instanceof Kamion){
          Kamion a = (Kamion) kamion ; 
          System.out.println("id " + a.getId());
          System.out.println("znacka " + a.getZnacka()); 
          System.out.println("model " + a.getModel());
          System.out.println("rok vyroby " + a.getRokVyroby());
          System.out.println("cena za hodinu " + a.getCenaZaHodinu());
          System.out.println("palivo " + a.getPalivo());
          System.out.println("mnozstvo paliva " + a.getMnozstvoPaliva());
          System.out.println("pocet kolies " + a.getPocetKoliest());
          System.out.println("pocet dveri " + a.getPocetDveri());
          System.out.println("rezervacia " + a.getJeRezervovane());
          System.out.println("---------------------------------------");
        }
      }
  }
  
 /**
     * Odstrani vozidlo podla jeho ID zo zoznamu vozidiel.
     * Ak sa nenaslo, vypise hlasku.
     */  
  public void odstranVozidlo(int id){
   boolean boloOdstranene = false;
   
   for (Vozidlo vozidlo: arr_vozidlo){
       if (vozidlo.getId() == id ) {
           boloOdstranene = true;
           arr_vozidlo.remove(vozidlo);
           System.out.println("Vozidlo uspesne odstranene");
           break;
       }
       
   }
    if (boloOdstranene == false){
         System.out.println("Vozidlo nenajdene");
    }
}

 /**
     * Odstrani zakaznika podla ID a uvolni rezervovane vozidlo.
     */
 public void odstranZakaznika(int id){
    boolean jeOdstranene = false;
    
    for (Zakaznik zakaznik:arr_zakaznik){
        if (zakaznik.getId()== id){
          jeOdstranene = true;  
          arr_zakaznik.remove(zakaznik);
          System.out.println("Zakaznik je  odstraneny");
        for(Vozidlo vozidlo: arr_vozidlo){
          String celyNazovAuta = vozidlo.getZnacka() + vozidlo.getModel();
          if (celyNazovAuta.equals(zakaznik.getMenoAuta()))  {
             vozidlo.setJeRezervovane(false);
            }
          }
        }
        break;
    }
      if (jeOdstranene == false){
         System.out.println("Zakaznik nenajdeny");
    }
    }
    
 /**
     * Dotankuje vsetky vozidla v systeme (nastavi im palivo na plno).
     */    
 public void dotankuj(){
    for (Vozidlo dotankujMiVozidlo: arr_vozidlo){
      if (dotankujMiVozidlo instanceof Auto){
        Auto auto = (Auto) dotankujMiVozidlo; 
        auto.dotankuj();
    }else if (dotankujMiVozidlo instanceof Autobus){
        Autobus autobus = (Autobus) dotankujMiVozidlo; 
        autobus.dotankuj();
      
     }else if (dotankujMiVozidlo instanceof Kamion){
        Kamion kamion = (Kamion) dotankujMiVozidlo; 
        kamion.dotankuj();
      
     }else if (dotankujMiVozidlo instanceof Motorka){
        Motorka motorka = (Motorka) dotankujMiVozidlo; 
        motorka.dotankuj();
      
    }
}
 }

  /**
     * Vypise vsetky aktualne rezervacie (zaznamy o zakaznikoch).
     */
public void vypisRezervacie(){
    for (Zakaznik r: arr_zakaznik){
       System.out.println("id: " + r.getId() );
        System.out.println("meno: " + r.getMeno() );  
       System.out.println("email: " + r.getEmail() ); 
       System.out.println("telefone cislo: " + r.getTelefoneCislo() ); 
       System.out.println("meno rezervovaneho auta: " + r.getMenoAuta() ); 
    }
}

  /**
     * Rezervuje vozidlo podla ID, ak nie je rezervovane.
     * @param id ID vozidla
     * @return nazov auta (znacka+model) alebo "nenajdene", ak sa nenaslo
     */
  public String rezervujVozidlo(int id){
    for (Vozidlo vozidlo: arr_vozidlo){

        if (vozidlo.getId() == id) {

            
            if (vozidlo.getJeRezervovane()) {
                System.out.println("Vozidlo je už rezervované.");
                return "nenajdene";
            }

            
            vozidlo.setJeRezervovane(true);
            System.out.println("Vozidlo bolo úspešne rezervované.");

            return vozidlo.getZnacka() + vozidlo.getModel();
        }
    }

    System.out.println("Vozidlo s daným ID nebolo nájdené.");
    return "nenajdene";
}




}