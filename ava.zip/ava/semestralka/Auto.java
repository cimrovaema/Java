import java.io.Serializable;
/**
 * Trieda Auto reprezentuje osobné auto v systéme.
 * Rozširuje triedu Vozidlo o počet dverí a počet kolies.
 * Implementuje aj rozhranie DotankujVozidlo.
 * 
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class Auto extends Vozidlo implements DotankujVozidlo, Serializable
{
  private int pocetKolies=4;
  private int pocetDveri;
  private String farba;
  
    /**
     * Vytvori nove auto so zadanymi parametrami.
     * Pocet kolies je pevny (4).
     */
  public Auto(String znacka,String model,int rokVyroby,float cenaZaHodinu,String palivo,int pocetDveri, boolean jeRezervovane, String farba){
     super(znacka,model,rokVyroby,cenaZaHodinu,palivo,jeRezervovane); 
     this.pocetDveri=pocetDveri;
     this.farba = farba;
  }
  
  public int getPocetKoliest(){
      return pocetKolies=pocetKolies;
  }
   public int getPocetDveri(){
      return pocetDveri;
  }  
  public float vypocitajCenuPrenajmuHod(float hodiny){
      return getCenaZaHodinu()*hodiny;
  }
  public float vypocitajCenuPrenajmuDni(float den){
      return getCenaZaHodinu()*24*den;
  }
  public void dotankuj(){
      setMnozstvoPaliva();
  }
  
  public String getFarba(){
      return farba;
  }
}