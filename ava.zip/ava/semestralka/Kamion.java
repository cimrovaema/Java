import java.io.Serializable;
/**
 * Trieda Kamion reprezentuje nákladné vozidlo v systéme.
 * Rozširuje triedu Vozidlo a pridáva počet dverí a kolies.
 * Implementuje rozhranie DotankujVozidlo.
 * 
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class Kamion extends Vozidlo implements DotankujVozidlo, Serializable
{
   
  private int pocetKolies=4;
  private int pocetDveri;
  
   /**
     * Vytvorí nový kamión so zadanými parametrami.
     * Počet kolies je predvolený.
     */
  public Kamion(String znacka,String model,int rokVyroby,float cenaZaHodinu,String palivo,int pocetDveri,boolean jeRezervovane){
     super(znacka,model,rokVyroby,cenaZaHodinu,palivo,jeRezervovane); 
     this.pocetDveri=pocetDveri;
  }
  public int getPocetKoliest(){
      return pocetKolies=pocetKolies;
  }
   public int getPocetDveri(){
      return pocetDveri;
  }   
  public float vypocitajCenuPrenajmuHod(float hodiny){
      return getCenaZaHodinu()*hodiny;
  }  
  public float vypocitajCenuPrenajmuDni(float den){
      return getCenaZaHodinu()*24*den;
  } 
  public void dotankuj(){
      setMnozstvoPaliva();
  }
}