import java.io.Serializable;
/**
 * Abstraktna trieda Vozidlo predstavuje zaklad pre vsetky typy vozidiel
 * v systeme pozicovne. Obsahuje spolocne vlastnosti ako znacka, model,
 * rok vyroby, cena za hodinu a informaciu, ci je vozidlo rezervovane.
 * Kazde vozidlo dostane automaticky vlastne ID.
 * 
 * @author Ema Cimrová
 * @version 8.12.2025
 */

abstract class Vozidlo implements Serializable
{
    private static int nextId = 1;
    protected int id;
    protected String znacka;
    protected String model;
    protected int rokVyroby;
    protected float cenaZaHodinu=20;
    protected String palivo;
    protected int mnozstvoPaliva=25;
    protected boolean jeRezervovane;
    
  /**
     * Vytvori nove vozidlo so zadanymi parametrami.
     * ID sa prideľuje automaticky.
     */  
 public Vozidlo(String znacka,String model,int rokVyroby,float cenaZaHodinu,String palivo, boolean jeRezervovane){
     this.znacka=znacka;
     this.model=model;
     this.rokVyroby=rokVyroby;
     this.cenaZaHodinu=cenaZaHodinu;
     this.palivo=palivo;
     this.jeRezervovane=jeRezervovane;
     
     // Priradí aktuálnu hodnotu nextId ako ID tomuto objektu
     this.id = nextId;
     // Zvýši nextId o 1, aby ďalší objekt dostal nasledujúce číslo (1, 2, 3...)
     nextId++;
 }
 
 public int getId(){
     return id;
 }
 public String getZnacka(){
     return znacka;
 }
 public String getModel(){
     return model;
 }
  public int getRokVyroby(){
     return rokVyroby;
 }  
  public float getCenaZaHodinu(){
     return cenaZaHodinu;
 }  
 public String getPalivo(){
     return palivo;
 }   
 public int getMnozstvoPaliva(){
     return mnozstvoPaliva;
 }  
  public boolean getJeRezervovane(){
     return jeRezervovane;
 }
 
 public void setMnozstvoPaliva(){
     this.mnozstvoPaliva=100;
 }
 public void setZnacka(String znacka){
     this.znacka=znacka;
 }
  public void setModel(String model){
     this.model=model;
 }  
 public void setRokVyroby(int rokVyroby){
     this.rokVyroby=rokVyroby;
 } 
 public void setCenaZaHodinu(float cenaZaHodinu){
     this.cenaZaHodinu=cenaZaHodinu;
 } 
 public void setPalivo(String palivo){
     this.palivo=palivo;
 } 
  public void setJeRezervovane(boolean jeRezervovane){ 
     this.jeRezervovane=jeRezervovane; 
 }
 
  /**
     * Vypocita cenu prenajmu za urcity pocet hodin.
     */
 abstract float vypocitajCenuPrenajmuHod(float hodiny);
 
   /**
     * Vypocita cenu prenajmu za pocet dni.
     */
 abstract float vypocitajCenuPrenajmuDni(float den);
}