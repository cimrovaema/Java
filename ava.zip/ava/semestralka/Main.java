import java.io.Serializable;
import java.io.*;
import java.util.Scanner;
/**
 * Hlavna trieda programu pre rezervacny system vozidiel.
 * Stara sa o menu, ukladanie a nacitavanie dat zo suboru.
 * 
 * @author Ema Cimrová
 * @version 8.12.2025
 */

public class Main
{
  /** Nazov suboru, do ktoreho sa ukladaju data. */
  public static String nazovsuboru = "subor.ser";
  
  /**
     *  nacita rezervacny system
     *  zobrazuje menu 
     */
  public static void main(String[] args)throws IOException, ClassNotFoundException{ 
      RezervovaciSystem rezervacie = IOkontrola();
     
      System.out.println("======== Vitajte v " + rezervacie.getNazovRezSystemu() + " ========");
      
     while (true){    
         vypisMenu();    
         Scanner vstup = new Scanner(System.in);
         int cislo = vstup.nextInt();
         if (cislo==1){
             rezervacie.vypisAuto();
             rezervacie.vypisAutobus();
              rezervacie.vypisMotorka();
               rezervacie.vypisKamion();
         }
         else if (cislo==0){
             break;
         }
         else if (cislo == 2){
             rezervacie.vypisAuto();
         }
         else if (cislo ==3){
             rezervacie.vypisMotorka();
         }
         else if (cislo ==4){
            System.out.println("1 : pridaj auto");
            System.out.println("2 : pridaj motorku");
            System.out.println("3 : pridaj autobus");
            System.out.println("4 : pridaj kamion");
                
            Scanner vyber = new Scanner(System.in);
            String vybranaMoznost = vyber.nextLine();
            if (vybranaMoznost.equals("1")){
                System.out.println("Zadaj znacku auta ");
                String znacka= vyber.nextLine();
                System.out.println("Zadaj model auta ");
                String model= vyber.nextLine();
                System.out.println("Zadaj rok auta ");
                String rokVyroby= vyber.nextLine();
                System.out.println("Zadaj cenu za hodinu auta ");
                String cenaZaHodinu= vyber.nextLine();
                System.out.println("Zadaj palivo auta ");
                String palivo= vyber.nextLine();
                System.out.println("Zadaj ci je Rezervovane auta ");
                String jeRezervovane= vyber.nextLine();
                System.out.println("Zadaj pocet dveri auta ");
                String pocetDveri= vyber.nextLine();
                    
                Auto auto = new Auto ( znacka, model, Integer.parseInt(rokVyroby), Float.parseFloat(cenaZaHodinu), 
                palivo, Integer.parseInt(pocetDveri), Boolean.parseBoolean(jeRezervovane), "ruzova");
                
                rezervacie.pridajAuto(auto);
                ulozData(rezervacie);
                
                    
             }
             else if (vybranaMoznost.equals("2")){
                System.out.println("Zadaj znacku motorky ");
                String znacka= vyber.nextLine();
                System.out.println("Zadaj model motorky ");
                String model= vyber.nextLine();
                System.out.println("Zadaj rok motorky ");
                String rokVyroby= vyber.nextLine();
                System.out.println("Zadaj cenu za hodinu motorky ");
                String cenaZaHodinu= vyber.nextLine();
                System.out.println("Zadaj palivo motorky ");
                String palivo= vyber.nextLine();
                System.out.println("Zadaj ci je Rezervovane motorky ");
                String jeRezervovane= vyber.nextLine();
                
                    
                Motorka motorka = new Motorka ( znacka, model, Integer.parseInt(rokVyroby), Float.parseFloat(cenaZaHodinu), 
                palivo, Boolean.parseBoolean(jeRezervovane));
                
                rezervacie.pridajMotorka(motorka);
                ulozData(rezervacie);
                
                    
             }
             else if (vybranaMoznost.equals("3")){
                System.out.println("Zadaj znacku autobusu ");
                String znacka= vyber.nextLine();
                System.out.println("Zadaj model autobusu ");
                String model= vyber.nextLine();
                System.out.println("Zadaj rok autobusu ");
                String rokVyroby= vyber.nextLine();
                System.out.println("Zadaj cenu za hodinu autobusu ");
                String cenaZaHodinu= vyber.nextLine();
                System.out.println("Zadaj palivo autobusu ");
                String palivo= vyber.nextLine();
                System.out.println("Zadaj ci je Rezervovane autobusu ");
                String jeRezervovane= vyber.nextLine();
                System.out.println("Zadaj pocet dveri autobusu ");
                String pocetDveri= vyber.nextLine();
                    
                Autobus autobus = new Autobus ( znacka, model, Integer.parseInt(rokVyroby), Float.parseFloat(cenaZaHodinu), 
                palivo, Integer.parseInt(pocetDveri), Boolean.parseBoolean(jeRezervovane));
                
                rezervacie.pridajAutobus(autobus);
                ulozData(rezervacie);
                
                    
             }
             else if (vybranaMoznost.equals("4")){
                System.out.println("Zadaj znacku kamionu ");
                String znacka= vyber.nextLine();
                System.out.println("Zadaj model kamionu ");
                String model= vyber.nextLine();
                System.out.println("Zadaj rok kamionu ");
                String rokVyroby= vyber.nextLine();
                System.out.println("Zadaj cenu za hodinu kamionu ");
                String cenaZaHodinu= vyber.nextLine();
                System.out.println("Zadaj palivo autobusu ");
                String palivo= vyber.nextLine();
                System.out.println("Zadaj ci je Rezervovane kamionu ");
                String jeRezervovane= vyber.nextLine();
                System.out.println("Zadaj pocet dveri kamionu ");
                String pocetDveri= vyber.nextLine();
                    
                Kamion kamion = new Kamion ( znacka, model, Integer.parseInt(rokVyroby), Float.parseFloat(cenaZaHodinu), 
                palivo, Integer.parseInt(pocetDveri), Boolean.parseBoolean(jeRezervovane));
                
                rezervacie.pridajKamion(kamion);
                ulozData(rezervacie);
                
                    
             }
            
            }
            else if (cislo ==5){
                System.out.println("zadaj id na odstranenie vozidla");
              
                    
                Scanner odstranenie = new Scanner(System.in);
                String cisloId = odstranenie.nextLine(); 
                if(jeCislo(cisloId)){
                    rezervacie.odstranVozidlo(Integer.parseInt(cisloId)); 
                  
                    ulozData(rezervacie);
                }
                else {
                System.out.println("zly vstup");
                }
             }
             else if (cislo == 6) {
                System.out.println("zadaj id na rezervovanie vozidla"); 
            
                Scanner rezervovanie = new Scanner(System.in);
                String cisloId = rezervovanie.nextLine(); 
            
                if (jeCislo(cisloId)) {
                    String nazovAuta = rezervacie.rezervujVozidlo(Integer.parseInt(cisloId));
            
                    
                    if ("nenajdene".equals(nazovAuta)) {
                        System.out.println("Rezervácia sa nevykonala.");
                    } else {
                        System.out.println("zadaj meno");
                        String meno = rezervovanie.nextLine();
                        System.out.println("zadaj email");
                        String email = rezervovanie.nextLine();
                        System.out.println("zadaj telefone cislo");
                        String telefoneCislo = rezervovanie.nextLine();
                        System.out.println("1: rezervacia na den");
                        System.out.println("2: rezervacia na hodinu");
                        String vybranyCas = rezervovanie.nextLine();
            
                        Zakaznik zakaznik = new Zakaznik(meno, email, Long.parseLong(telefoneCislo), nazovAuta);
                        rezervacie.pridajZakaznika(zakaznik, Float.parseFloat(vybranyCas)); 
                        rezervacie.pridajHistoria(zakaznik);
                        ulozData(rezervacie);
                    }
                } else {
                    System.out.println("zly vstup");
                }
            }

            else if (cislo ==7){
               rezervacie.vypisRezervacie();
            }   
           else if (cislo ==8){   
             rezervacie.vypisHistoria();
            }
             else if (cislo ==9){
            System.out.println("Zadaj id pre odstranenie zakaznika");
            
            Scanner vyber1 = new Scanner(System.in);  
            String vybranaMoznost = vyber1.nextLine();
             if(jeCislo(vybranaMoznost)){
                  rezervacie.odstranZakaznika(Integer.parseInt(vybranaMoznost)); 
            }else {
                System.out.println("zly zakaznik");
                }
            
            } else if (cislo ==10){
                rezervacie.dotankuj();
                
            }else if (cislo ==11){
                 System.out.println("peniaze " + rezervacie.getPeniaze());
            }
            
            else if (cislo == 12) {
                System.out.println("Zadaj znacku: ");
                Scanner vyberVolba12 = new Scanner(System.in);
                String znacka = vyberVolba12.nextLine();
                
                System.out.println("zadaj farbu: ");
                String farba = vyberVolba12.nextLine();
                
                rezervacie.filterCarsByBrandAndColor(znacka, farba);
                
            }
            
         }
        }
        
   /**
     * Ulozi objekt RezervovaciSystem do suboru pomocou serializacie.
     */     
   public static void ulozData(RezervovaciSystem rezervacia) throws IOException{
     FileOutputStream file = new FileOutputStream(nazovsuboru);
        ObjectOutputStream out = new ObjectOutputStream(file);

        out.writeObject(rezervacia);

        out.close();
        file.close();

        System.out.println("Data has been saved.");  
   }
   
     /**
     * Nacita objekt RezervovaciSystem zo suboru.
     */
   public static RezervovaciSystem nacitajData(RezervovaciSystem rezervacia) throws IOException , ClassNotFoundException{
   FileInputStream file = new FileInputStream(nazovsuboru);
        ObjectInputStream in = new ObjectInputStream(file);

        rezervacia = (RezervovaciSystem)in.readObject();

        in.close();
        file.close();

        System.out.println("Data has been loaded.");

        return rezervacia;
}
// tato metoda kontroluje ci subor existuje
  /**
     * Metoda skontroluje, ci subor so seriovanymi datami existuje.
     * Ak existuje, data nacita. Ak nie, vytvori novy system s par
     * prednastavenymi vozidlami.
     */
public static RezervovaciSystem IOkontrola ()throws IOException , ClassNotFoundException{
    File file = new File(nazovsuboru);
    RezervovaciSystem ulozisko;
    
    if (file.exists()) {
        ulozisko = new RezervovaciSystem();
        ulozisko = nacitajData(ulozisko);
    }
    else { 
        ulozisko = new RezervovaciSystem();
        Auto auto = new Auto("Citroen", "Picasso",2008,20.0f,"diesel",4,true, "modra");  
        ulozisko.pridajAuto(auto);
        auto = new Auto("Citroen", "Berlingo",2008,40.0f,"diesel",4,false, "modra");  
        ulozisko.pridajAuto(auto);
        auto = new Auto("Citroen", "C5 Aircross",2008,80.0f,"diesel",4,false, "modra");  
        ulozisko.pridajAuto(auto);
        auto = new Auto("Skoda", "Octavia",2001,15.0f,"diesel",4,false, "biela");
        ulozisko.pridajAuto(auto);
        auto = new Auto("Skoda", "Fabia",2001,15.0f,"diesel",4,false, "biela");
        ulozisko.pridajAuto(auto);
        auto = new Auto("Volkswagen", "Touran",2018,25.0f,"diesel",4,false, "cierna");
        ulozisko.pridajAuto(auto);
        auto = new Auto("Volkswagen", "Passat",2005,15.0f,"benzin",4,false, "cierna");
        ulozisko.pridajAuto(auto);
        auto = new Auto("Volkswagen", "Tiguan",2020,95.0f,"diesel",4,false, "cierna");
        ulozisko.pridajAuto(auto);
        Motorka motorka = new Motorka("Honda", "fabia", 2026, 5.0f, "benzin",false);
        ulozisko.pridajMotorka(motorka);
        Kamion kamion = new Kamion("Scania", "cactus",2001,100.0f,"diesel",2,true);
        ulozisko.pridajKamion(kamion);
        ulozData(ulozisko);
    }
    return ulozisko;
}

public static void vypisMenu(){
    System.out.println("m : zobraz menu");
    System.out.println("1 : vypis vsetky vozidla");
    System.out.println("2 : vypis vsetky auta");
    System.out.println("3 : vypis vsetky motorky");
    System.out.println("4 : pridanie vozidla");
    System.out.println("5 : vymazanie vozidla");
    System.out.println("6 : rezervovanie vozidla");
    System.out.println("7 : vypis rezervacii");
    System.out.println("8 : historia");
    System.out.println("9 : odstranenie zakaznika");
    System.out.println("10 : dotankuj");
    System.out.println("11 : zobrazit peniaze");
    System.out.println("12 : vyhladat auta podla znacky a farby");
    System.out.println("0 : ukonci program");

}

 /**
     * Skontroluje, ci zadany retazec je cele cislo.
     * @return true ak sa podarilo previest na int, inak false
     */
public static boolean jeCislo(String str){
    try{
        Integer.parseInt(str);
        return true;
    } catch(NumberFormatException e)
    {
        return false;
    }
}


}