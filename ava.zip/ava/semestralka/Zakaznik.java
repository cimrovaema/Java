import java.io.Serializable;

/**
 * Trieda Zakaznik predstavuje zákazníka v systéme požičovne.
 * Uchováva základné údaje ako meno, email, telefónne číslo a
 * názov auta, ktoré má prenajaté. Každý zákazník dostane vlastné ID.
 *
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class Zakaznik implements Serializable
{
   private static int nextId = 1;
   protected int id;
   private String meno;
   private String email;
   private long telefoneCislo;
   private String menoAuta;
   
    /**
     * Vytvorí nového zákazníka so zadanými údajmi.
     * ID sa prideľuje automaticky.
     */
   public Zakaznik(String meno, String email, long telefoneCislo, String menoAuta){
       this.meno=meno;
       this.email=email;
       this.telefoneCislo=telefoneCislo;
       this.menoAuta=menoAuta;
       
       this.id = nextId;
       nextId++;
   }
   
   public int getId(){
     return id;
   }
   public String getMeno(){
       return meno;
   }
   public String getEmail(){
       return email;
   }
   public long getTelefoneCislo(){
       return telefoneCislo;
   }
   public String getMenoAuta(){
       return menoAuta;
   }
   
   public void setMeno(String meno){
       this.meno=meno;
   }
   public void setEmail(String email){
       this.email=email;
   }
   public void setTelefoneCislo(long telefoneCislo){
       this.telefoneCislo=telefoneCislo;
   } 
   
}