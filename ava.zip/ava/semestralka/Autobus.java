import java.io.Serializable;
/**
 * Trieda Autobus reprezentuje autobus v systéme požičovne.
 * Rozširuje triedu Vozidlo a pridáva informácie ako počet dverí,
 * počet kolies a počet sedadiel.
 * Implementuje rozhranie DotankujVozidlo.
 *
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class Autobus extends Vozidlo implements DotankujVozidlo, Serializable
{
  private int pocetSedadiel;         
  private int pocetKolies=6;
  private int pocetDveri;
  
   /**
     * Vytvorí nový autobus so zadanými parametrami.
     * Počet kolies je pevný (6).
     */
  public Autobus(String znacka,String model,int rokVyroby,float cenaZaHodinu,String palivo,int pocetDveri,boolean jeRezervovane){
     super(znacka,model,rokVyroby,cenaZaHodinu,palivo,jeRezervovane); 
     this.pocetDveri=pocetDveri;
  }
  public int getPocetKoliest(){
      return pocetKolies=pocetKolies;
  }
   public int getPocetDveri(){
      return pocetDveri;
  }    
    public int getPocetSedadiel(){
      return pocetSedadiel;
  }  
  public float vypocitajCenuPrenajmuHod(float hodiny){
      return getCenaZaHodinu()*hodiny;
  }  
  public float vypocitajCenuPrenajmuDni(float den){
      return getCenaZaHodinu()*24*den;
  }  
  public void dotankuj(){
      setMnozstvoPaliva();
  }
    
    
}