import java.io.Serializable;
/**
 * Trieda Motorka reprezentuje motorku v systéme požičovne.
 * Rozširuje triedu Vozidlo a pridáva informáciu o počte kolies.
 * Implementuje rozhranie DotankujVozidlo.
 *
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public class Motorka extends Vozidlo implements DotankujVozidlo, Serializable
{
  private int pocetKolies=2;
  
    /**
     * Vytvorí novú motorku so zadanými parametrami.
     * Počet kolies je pevne nastavený na 2.
     */
  public Motorka(String znacka,String model,int rokVyroby,float cenaZaHodinu,String palivo,boolean jeRezervovane){
     super(znacka,model,rokVyroby,cenaZaHodinu,palivo,jeRezervovane); 
     
  }
  public int getPocetKoliest(){
      return pocetKolies=pocetKolies;
  }  
  public float vypocitajCenuPrenajmuHod(float hodiny){
      return getCenaZaHodinu()*hodiny;
  }  
  public float vypocitajCenuPrenajmuDni(float den){
      return getCenaZaHodinu()*24*den;
  }  
  public void dotankuj(){
      setMnozstvoPaliva();
  }
    
  
}