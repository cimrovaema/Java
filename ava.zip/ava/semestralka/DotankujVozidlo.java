
/**
 * Rozhranie DotankujVozidlo slúži na to, aby triedy,
 * ktoré ho implementujú, mohli dotankovať vozidlo.
 * Obsahuje jedinú metódu dotankuj().
 *
 * @author Ema Cimrová
 * @version 8.12.2025
 */
public interface DotankujVozidlo
{
       /**
     * Dotankuje vozidlo na plno.
     * Konkrétna implementácia je v jednotlivých triedach (Auto, Motorka, ...).
     */ 
   void dotankuj();
   
    
    
    
    
}